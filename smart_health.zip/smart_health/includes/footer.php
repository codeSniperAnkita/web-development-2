<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<link rel="stylesheet" href="/smart_health/assets/style.css">
<body>
 <div class="footer" style="text-align: center;">
    Smart Health Prediction System <br>
    © Reserved by ANKITA KUMARI
</div>

</body>
</html>
