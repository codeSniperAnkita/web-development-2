<!DOCTYPE html>
<html>
<head>
    <title>Smart Health Prediction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
</head>
<body>

<!-- NAVBAR START -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand fw-bold" href="/smart_health/index.php">Smart Health</a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
      <a href="/smart_health/index.php">Home</a>
      <a href="/smart_health/user/register.php">Register</a>
      <a href="/smart_health/user/login.php">Login</a>
      <a href="/smart_health/admin/login.php">Doctor</a>
      <a href="/smart_health/contact.php">Contact</a>

      </ul>
    </div>
  </div>
</nav>
<!-- NAVBAR END -->

<div class="container mt-5">
